//
//  ViewController.h
//  lazyTableUpdate
//
//  Created by Bob Wu on 12-5-9.
//  Copyright (c) 2012年 veex. All rights reserved.


#import <UIKit/UIKit.h>
#import "WQTableViewController.h"

@interface ViewController : WQTableViewController <WQTableViewDelegate>
{
    
}
@property (strong, nonatomic) IBOutlet UITableView *mytable;

@end
