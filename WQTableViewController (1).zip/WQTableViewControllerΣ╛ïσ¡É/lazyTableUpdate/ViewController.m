//
//  ViewController.m
//  lazyTableUpdate
//
//  Created by Bob Wu on 12-5-9.
//  Copyright (c) 2012年 veex. All rights reserved.
//

#import "ViewController.h"
#import "SBJson.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize mytable;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Home", @"Home");
    }
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    wqTable=mytable;
	// Do any additional setup after loading the view, typically from a nib.
    NSString *jsonStr = [NSString stringWithContentsOfURL:[NSURL URLWithString:@"http://phobos.apple.com/WebObjects/MZStoreServices.woa/ws/RSS/toppaidapplications/limit=75/json"] encoding:NSUTF8StringEncoding error:nil];
    NSDictionary *dic = [jsonStr JSONValue];
    
    tableDataArray = [[dic valueForKey:@"feed"] valueForKey:@"entry"];
    delegate=self;
}

// customize the number of rows in the table view
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	int count = [tableDataArray count];
    return count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	static NSString *CellIdentifier = @"LazyTableCell";

    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                       reuseIdentifier:CellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }

    NSDictionary *item = [tableDataArray objectAtIndex:indexPath.row];
    
    cell.textLabel.text = [[item valueForKey:@"im:name"] valueForKey:@"label"];
    cell.detailTextLabel.text = [[item valueForKey:@"summary"] valueForKey:@"label"];
    
    NSString *imageName = [[[[tableDataArray objectAtIndex:indexPath.row] valueForKey:@"im:name"] valueForKey:@"label"] stringByAppendingString:@".temp"];
        
    
    NSString *imageDataPath = [NSHomeDirectory() stringByAppendingPathComponent:[@"Library/Caches/" stringByAppendingString:imageName]];
    UIImage *image = [UIImage imageWithData:[NSData dataWithContentsOfFile:imageDataPath]];
    if (image) {
        cell.imageView.image = image;
    }
    else {
        cell.imageView.image = [UIImage imageNamed:@"Placeholder.png"];
        //placeholder为在未加载完成加载图片时显示的默认图片
    }
    return cell;
}


- (void)viewDidUnload
{
    [self setMytable:nil];
    wqTable = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

-(void)cellImageDidLoad:(NSIndexPath *)indexPath image:(UIImage *)image
{
    UITableViewCell *cell = [wqTable cellForRowAtIndexPath:indexPath];
    cell.imageView.image = image;
}
@end
